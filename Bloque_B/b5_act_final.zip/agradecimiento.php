<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agradecimiento</title>
</head>
<body>
    <h1>¡Gracias por agregar un nuevo interés!</h1>
    <p>Tu interés ha sido agregado exitosamente a la lista.</p>
    <a href="index.php">Volver a la página principal</a>
</body>
</html>